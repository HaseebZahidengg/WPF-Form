﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace TaskNo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();


            Gender.Items.Add("Select");
            Gender.Items.Add("Male");            //Used to add drop down values in ComboBox
            Gender.Items.Add("Female");
            Gender.Items.Add("Others");
            Gender.SelectedItem = "Select";


            Department.Items.Add("Select");
            Department.Items.Add("Web");
            Department.Items.Add("SQA");
            Department.Items.Add("HR");
            Department.SelectedIndex = 0;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string str1 = NameText.Text;

            string str2 = FatherName.Text;

            string str3 = CNIC.Text.ToString();

            string str4 = Designation.Text;

            string dte = DOB.SelectedDate.ToString();

            //Gender information
            string genderValue = "";


            if (Gender.SelectedItem == "Select")
            {
                MessageBox.Show("Please enter gender");
            }
            else
            {
                genderValue = Gender.SelectedItem.ToString();

            }

            //Department Information

            string departmentValue = "";

            if (Department.SelectedItem == "Select")
            {
                MessageBox.Show("Please enter Department");
            }
            else
            {
                departmentValue = Department.SelectedItem.ToString();

            }

            string isManager = "";

            if (IsManager.IsChecked == true)
            {
                isManager = "Yes";
            }
            else
            {
                isManager = "No";
            }

            //MessageBox.Show(genderValue);

            //MessageBox.Show("Name: "+str1 + " Father's Name: " + str2 + " CNIC: "+ str3 + " Designation: " + str4);
            //MessageBox.Show(genderValue);

            //Saving data
            StreamWriter CSV = new StreamWriter("Form.csv", true);
            CSV.WriteLine(str1 + "," + str2 + "," + str3 + "," + str4 + "," + dte + "," + genderValue + "," + departmentValue + "," + isManager);
            CSV.Close();
        }


        private void View_Details(object sender, RoutedEventArgs e)
        {
            StreamReader CSV_Read = new StreamReader("Form.csv");
            string temp;
            //var temp = CSV_Read.ReadLine();

            while((temp =CSV_Read.ReadLine()) != null)
            {
                MessageBox.Show(temp);
            }
            

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
